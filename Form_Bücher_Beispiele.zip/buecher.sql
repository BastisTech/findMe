-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 02. Jun 2020 um 22:53
-- Server-Version: 10.4.11-MariaDB
-- PHP-Version: 7.2.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `01bücher`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bücher`
--

CREATE TABLE `bücher` (
  `B_ID` int(2) NOT NULL,
  `B_Büchername` varchar(30) NOT NULL,
  `B_Schriftsteller` varchar(30) NOT NULL,
  `B_Ersterscheinungsjahr` varchar(4) NOT NULL,
  `B_Verlag` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `bücher`
--

INSERT INTO `bücher` (`B_ID`, `B_Büchername`, `B_Schriftsteller`, `B_Ersterscheinungsjahr`, `B_Verlag`) VALUES
(1, 'Andersens Märchen', 'Andersen, Hans Christian', '2007', 'Edition Lempertz'),
(2, 'Stolz und Vorurteil', 'Austen, Jane', '2016', 'dtv Verlagsgesellschaft'),
(3, 'Vater Goriot', 'Balzac, Honoré de', '2008', 'FISCHER Taschenbuch'),
(4, 'Drei Romane. Molloy. Malone st', 'Samuel Beckett', '2005', 'Suhrkamp Verlag'),
(5, 'Das Dekameron', 'Giovanni Boccaccio', '2009', 'Anaconda'),
(6, 'Fiktionen', 'Borges, Jorge Luis', '1992', 'FISCHER Taschenbuch'),
(7, 'Sturmhöhe', 'Brontë, Emily', '1997', 'dtv Verlagsgesellschaft'),
(8, 'Der Fremde', 'Camus, Albert', '1996', 'Rowohlt Taschenbuch'),
(9, 'Die Gedichte', 'Celan, Paul', '2005', 'Suhrkamp Verlag'),
(10, 'Reise ans Ende der Nacht', 'Céline, Louis-Ferdinand', '2004', 'Rowohlt Taschenbuch');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `bücher`
--
ALTER TABLE `bücher`
  ADD PRIMARY KEY (`B_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
