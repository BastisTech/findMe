<?php
$db = mysqli_connect("localhost", "root", "", "01bücher");
if(!$db)
{
  exit("Verbindungsfehler: ".mysqli_connect_error());
}
?>