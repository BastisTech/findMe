<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css" type="text/css">
    </head>
    <body>
    <?php
        include("connect.php");
        $ID=$_GET["ID"];
        $loeschen = "DELETE FROM bücher WHERE B_ID = '$ID'";
        $loesch = mysqli_query($db, $loeschen);
            if($loesch){
                 echo "Löschen hat geklappt";
             }
             else{
                echo "$loeschen <br>";
                }
    ?>
    <br>
    <h3><a href="index.php">Zurück zur Ausgabe</a></h3>
    <br>
    </body>
</html>