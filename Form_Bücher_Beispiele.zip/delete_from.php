<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <tile> </title>
        <link rel="stylesheet" href="style.css" type="text/css">
    </head>
    <body>
        <form action="delete.php" method="GET">
            B_ID:<input type="text" name="ID"><br>
            <input type="submit" value="Buch löschen">
        </form>
    </body>
</html>