<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta charset="utf-8">
		<link rel="stylesheet" href="style.css" type="text/css">
    </head>
    <body>
		<?php
		
			include("connect.php");	
			$ergebnis = mysqli_query($db, "SELECT * FROM bücher");
			echo"<table border='1'>\n";
			while($row = mysqli_fetch_object($ergebnis))
			{
			  echo "<tr> <td>";
			   $pfad ="grafiken/".$row->B_ID.".jpg";
			  if (file_exists($pfad)) {
				echo "<img src='grafiken/$row->B_ID.jpg' width='100px'>";
			  }
			  else {
				 echo "X"; 
			  }
			  echo "</td>\n <td>$row->B_ID</td>  <td>$row->B_Büchername</td> <td>$row->B_Schriftsteller</td>\n<td>$row->B_Ersterscheinungsjahr</td><td>$row->B_Verlag</td>";

			}
			echo "</table>\n";
			
		?>
		<br>
		<br><a href="insert_form.php">Bücher hinzufügen</a><br>
		<br><a href="delete_from.php">Bücher löschen</a><br>
		<br><a href="update_form.php">Bücher ändern</a>
		
    </body>
</html>