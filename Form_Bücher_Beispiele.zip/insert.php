<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css" type="text/css">
    </head>
    <body>
    <?php
        include("connect.php");
        $BID=$_GET["BID"];
        $bname=$_GET["bname"];
        $SS=$_GET["SS"];
        $date=$_GET["date"];
        $verlag=$_GET["verlag"];
        $eintrag = "INSERT INTO bücher (B_ID, B_Büchername, B_Schriftsteller, B_Ersterscheinungsjahr, B_Verlag) VALUES ('$BID', '$bname', '$SS', '$date', '$verlag')";
        $eintragen = mysqli_query($db, $eintrag);
            if($eintragen){
                echo "Eintrag hat geklappt";
             }
            else{
                echo "$eintrag <br>";
            }
    ?>
    <br><a href="index.php">Zurück zur Ausgabe</a>
    </body>
</html>