<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css" type="text/css">
    </head>
    <body>
        <form action="insert.php" method="GET">
            B_ID:<input type="text" name="BID"><br>
            B_Büchername:<input type="text" name="bname"><br>
            B_Schriftsteller:<input type="text" name="SS"><br>
            B_Ersterscheinungsjahr:<input type="text" name="date"><br>
            B_Verlag:<input type="text" name="verlag"><br>
            <input type="submit" value="Buch hinzufügen"><br>
        </form>
    </body>
</html>