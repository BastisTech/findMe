<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>insert</title>
        <link rel="stylesheet" href="style.css" type="text/css">
    </head>
    <body>
        <?php
            include("connect.php");
            $BID=$_GET["BID"];
            $bname=$_GET["bname"];
            $SS=$_GET["SS"];
            $date=$_GET["date"];
            $verlag=$_GET["verlag"];
            $aendern = "UPDATE bücher Set B_Büchername='$bname', B_Schriftsteller='$SS', B_Ersterscheinungsjahr='$date', B_Verlag='$verlag' WHERE B_ID='$BID'";
            $update = mysqli_query($db, $aendern);
            if ($update)
            {echo "Ändern hat geklappt <br>";}
            else
            {echo "$aendern <br>";}
        ?>
        <a href="index.php">Zurück zur Ausgabe</a>
    </body>
</html>