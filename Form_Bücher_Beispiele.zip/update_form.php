<!doctype html>
 <html>  
 <head> 
	 <meta charset="utf-8">
	<title> Update-From</title>
</head>
<body> 															
	<?php       
		 include("connect.php");
					 
		 $BestNr=$_GET["BestNr"];             $ergebnis = mysqli_query($db, "SELECT * FROM bestellungen WHERE BestNr='$BestNr'");             $row= mysqli_fetch_object($ergebnis);         ?>         <form action="update.php" method="GET">             BestNr:<input type="text" name ="BestNr" value="<?php echo "$row->BestNr";?>"><br>             Anrede:<input type="radio" name ="A" value="Frau">Frau              Mann<input type="radio" name ="A" value ="Herr"              Vorname:<input type="text" name ="VN"             Nachname:<input type="text" name ="NN" value="<?php echo "$row->Nachname";?>"><br>             KistlArt: <select name="KistlArt"><br>            <?php             include("connect.php");              $ergebnis = mysqli_query($db, "SELECT * FROM Kistl");                    while($row1 = mysqli_fetch_object($ergebnis))             {                 echo"<option value='$row1->ID'>$row1->ID $row1->KistlName</option>";             }